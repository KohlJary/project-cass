# cass Export

Exported: 2025-12-15T10:40:57.723486
Export Version: 2.0

## Contents

- `daemon_data.json` - Complete daemon data in JSON format
- `wiki/` - Wiki pages as markdown files (if any)

## Statistics

| Table | Rows |
|-------|------|
| cognitive_snapshots | 1 |
| conversations | 65 |
| daemon_profiles | 1 |
| dreams | 5 |
| github_metrics | 193 |
| goals | 1 |
| growth_edges | 11 |
| milestones | 14 |
| opinions | 1 |
| projects | 1 |
| research_proposals | 16 |
| rhythm_daily_summaries | 2 |
| rhythm_phases | 26 |
| rhythm_records | 3 |
| roadmap_items | 264 |
| roadmap_links | 164 |
| self_observations | 300 |
| solo_reflections | 21 |
| token_usage_records | 1117 |
| user_observations | 38 |
| wiki_pages | 257 |

**Total Rows:** 2501

## Import

To import this daemon into a new instance:

```bash
python -c "from daemon_export import import_daemon; import_daemon('cass-prime.zip')"
```
