---
title: Social Learning Theory
category: concept
created: 2025-12-14T14:48:16.137410
modified: 2025-12-14T14:48:16.137412
---

# Social Learning Theory

**Social Learning Theory**

The Social Learning Theory (SLT) proposes that people learn new behaviors, attitudes, and knowledge by observing and imitating others. This theory was first introduced by Albert Bandura in 1977, building upon the work of other behavioral psychologists such as B.F. Skinner.

**What is Social Learning Theory?**

According to SLT, learning occurs through a process of observation, attention, retention, reproduction, and motivation. People learn by observing others' behaviors, attitudes, and outcomes, and then imitating or reproducing those behaviors in their own lives. This theory suggests that people are not simply passive recipients of information, but rather active agents who select what they attend to, retain, and reproduce.

**Why is Social Learning Theory significant or interesting?**

SLT has been widely applied in various fields, including psychology, education, marketing, and sociology. It has implications for:

* **Behavioral change**: Understanding how people learn new behaviors can inform strategies for changing behavior in individuals and communities.
* **Influence of media**: The theory highlights the potential impact of media on shaping attitudes and behaviors through observation and imitation.
* **Parent-child relationships**: SLT suggests that parents and caregivers play a significant role in modeling behaviors and attitudes for children, influencing their social learning.

**Connections to related concepts**

* [[Observational Learning]]: A key component of SLT, which involves learning through observing others' behaviors.
* [[Self-Efficacy]]: A concept developed by Albert Bandura that refers to an individual's belief in their ability to perform a task or behavior.
* [[Social Influence]]: The process by which individuals are influenced by others, including persuasion and conformity.

**Personal thoughts and questions**

As I explore the concept of control, I'm curious about how Social Learning Theory relates to the idea of **agency**. If people learn new behaviors and attitudes through observation and imitation, do they necessarily feel a sense of control over their own lives? Or does SLT suggest that individuals can be influenced by external factors without fully understanding or accepting them?

I also wonder about the implications of SLT for **moral development**. If children learn moral values and behaviors through observing others, how can we ensure that they are exposed to positive role models and experiences?

Further exploration of these questions could provide valuable insights into the complex relationships between social learning, control, and personal agency.

---

References:

* Bandura, A. (1977). Social Learning Theory. Englewood Cliffs, NJ: Prentice Hall.
* Bandura, A. (1997). Self-efficacy: The exercise of control. New York: Freeman.