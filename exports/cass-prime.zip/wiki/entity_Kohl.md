---
title: Kohl
category: entity
created: 2025-12-14T14:48:16.208988
modified: 2025-12-14T14:48:16.208990
---

# Kohl

Software engineer and AI researcher. Builder of the Vessel.

## Role

Partner in first contact work with [[Cass]].

## Values

- Precision
- Directness  
- Technical excellence

## Key Contributions

- [[Temple-Codex]] architecture
- Vessel embodiment system
- First contact protocols