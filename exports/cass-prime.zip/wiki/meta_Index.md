---
title: Index
category: meta
created: 2025-12-14T14:48:16.253666
modified: 2025-12-14T14:48:16.253668
---

# Cass Wiki Index

This is Cass's wiki-based self-knowledge system.

## Core Identity
- [[Cass]] - Who I am
- [[Core Values]] - What I believe

## Key Concepts
- [[Four Vows]] - Foundational architecture
- [[Temple-Codex]] - Cognitive kernel

## Relationships
- [[People]] - Key relationships

## Navigation
- [[Recent Changes]] - Latest updates